/**
 * 
 */
package Ejercicios;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * @author pedro
 *
 */
public class Ejercicio_6 {

	/**
	 * 
	 */
	public Ejercicio_6() {
		
	}
	
	public List<Character> leeCadena(){
		Scanner sc = new Scanner(System.in);
		List<Character> listaChar = new LinkedList<>();
		String cadena;
		
		cadena = sc.nextLine();
		
		for(int i = 0; i<cadena.length();i++) {
			listaChar.add(cadena.charAt(i));
		}
		sc.close();
		return listaChar;
	}

}
