/**
 * 
 */
package Ejercicios;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;


/**
 * @author pedro
 *
 */
public class Ejercicio_5 {

	/**
	 * 
	 */
	public Ejercicio_5() {
		
	}
	
	public List<Integer> fusion(List<Integer> lista, List<Integer> lista2) {
		List<Integer>listafinal = new LinkedList<>();
		
		for(int i = 0; i<5; i++) {
			int temp = (int) (Math.random()*100);
			lista.add(temp);
		}
		Collections.sort(lista);
		for(int j = 0; j<5; j++) {
			int temp2 = (int)(Math.random()*100);
			lista2.add(temp2);
		}
		Collections.sort(lista2);
		System.out.println("Primera lista: " + lista);
		System.out.println("Segunda lista: " + lista2);
		System.out.println("");
		listafinal.addAll(lista);
		listafinal.addAll(lista2);
		System.out.println("Esta es la lista de la union de las otras dos: ");
		
		return listafinal;
	}
}
