/**
 * 
 */
package Ejercicios;

import java.util.TreeSet;

/**
 * @author estudiante
 *
 */
public class Ejercicio_3 {

	/**
	 * 
	 */
	public Ejercicio_3() {
		
	}
	
	public TreeSet<Integer> diferencia(TreeSet<Integer> lista, TreeSet<Integer> lista2) {
		lista = new TreeSet<>();
		lista2 = new TreeSet<>();
		
		for(int i = 0; i<5; i++) {
			int temp = (int) (Math.random()*100);
			lista.add(temp);
		}
		for(int j = 0; j<5; j++) {
			int temp2 = (int)(Math.random()*100);
			lista2.add(temp2);
		}
		System.out.println("Primera lista: " + lista);
		System.out.println("Segunda lista: " + lista2);
		System.out.println("");
		lista.removeAll(lista2);
		System.out.println("Mostramos los elementos que estan en la primera lista y no en la segunda: ");
		return lista;
	}
}
