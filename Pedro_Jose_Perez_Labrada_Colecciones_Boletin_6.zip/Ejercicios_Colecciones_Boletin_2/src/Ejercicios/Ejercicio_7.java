/**
 * 
 */
package Ejercicios;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * @author pedro
 *
 */
public class Ejercicio_7 {

	/**
	 * 
	 */
	public Ejercicio_7() {
		
	}
	
	public List<Character> uneCadena(List<Character> listaChar1, List<Character> listaChar2){
		Scanner sc = new Scanner(System.in);
		List<Character> listaChar = new LinkedList<>();
		String cadena;
		String cadena2;
		
		cadena = sc.nextLine();
		
		for(int i = 0; i<cadena.length();i++) {
			listaChar1.add(cadena.charAt(i));
		}
		
		System.out.println("Ahora introduzca la segunda cadena.");
		cadena2 = sc.nextLine();
		
		for(int i = 0; i<cadena2.length();i++) {
			listaChar2.add(cadena2.charAt(i));
		}
		
		listaChar.addAll(listaChar1);
		listaChar.addAll(listaChar2);
		
		sc.close();
		return listaChar;
	}

}
