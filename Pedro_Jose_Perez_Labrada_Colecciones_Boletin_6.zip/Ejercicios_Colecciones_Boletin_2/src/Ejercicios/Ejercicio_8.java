/**
 * 
 */
package Ejercicios;

import java.util.LinkedList;
import java.util.List;

/**
 * @author pedro
 *
 */
public class Ejercicio_8 {

	/**
	 * 
	 */
	public Ejercicio_8() {
		
	}
	
	public List<Integer> clonaLista(List<Integer> lista){
		List<Integer> listaClon = new LinkedList<>();
		
		for(int i = 0; i<10; i++) {
			int temp = (int)(Math.random()*10);
			lista.add(temp);
		}
		
		listaClon = lista;
		
		System.out.println(lista);
		
		return listaClon;
	}

}
