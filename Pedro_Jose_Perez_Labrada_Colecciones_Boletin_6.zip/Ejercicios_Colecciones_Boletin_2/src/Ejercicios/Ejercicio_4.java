/**
 * 
 */
package Ejercicios;

import java.util.TreeSet;

/**
 * @author estudiante
 *
 */
public class Ejercicio_4 {

	/**
	 * 
	 */
	public Ejercicio_4() {
		
	}
	
	public boolean incluido(TreeSet<Integer> lista, TreeSet<Integer> lista2) {
		lista = new TreeSet<>();
		lista2 = new TreeSet<>();
		boolean incluido = false;
		
		for(int i = 0; i<5; i++) {
			int temp = (int) (Math.random()*100);
			lista.add(temp);
		}
		for(int j = 0; j<5; j++) {
			int temp2 = (int)(Math.random()*100);
			lista2.add(temp2);
		}
		
			if(lista.containsAll(lista2)) {
				incluido = true;
			}
			
		System.out.println("Primera lista: "+lista);
		System.out.println("Segunda lista: "+lista2);
		System.out.println("");
		return incluido;
	}
}
