/**
 * 
 */
package Main;


import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

import Ejercicios.Ejercicio_1;
import Ejercicios.Ejercicio_2;
import Ejercicios.Ejercicio_3;
import Ejercicios.Ejercicio_4;
import Ejercicios.Ejercicio_5;
import Ejercicios.Ejercicio_6;
import Ejercicios.Ejercicio_7;
import Ejercicios.Ejercicio_8;

/**
 * @author estudiante
 *
 */
public class Main {

	/**
	 * 
	 */
	public Main() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Ejercicio_1 ej1 = new Ejercicio_1();
		Ejercicio_2 ej2 = new Ejercicio_2();
		Ejercicio_3 ej3 = new Ejercicio_3();
		Ejercicio_4 ej4 = new Ejercicio_4();
		Ejercicio_5 ej5 = new Ejercicio_5();
		Ejercicio_6 ej6 = new Ejercicio_6();
		Ejercicio_7 ej7 = new Ejercicio_7();
		Ejercicio_8 ej8 = new Ejercicio_8();
		
		TreeSet<Integer>lista = new TreeSet<>();
		TreeSet<Integer>lista2 = new TreeSet<>();
		List<Integer> lista3 = new LinkedList<>();
		List<Integer> lista4 = new LinkedList<>();
		List<Character> listaChar1 = new LinkedList<>();
		List<Character> listaChar2 = new LinkedList<>();


		
		
//		System.out.println(ej1.unirLista(lista, lista2));
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
//		System.out.println(ej2.intersecLista(lista, lista2));
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
//		System.out.println(ej3.diferencia(lista, lista2));
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
//		System.out.println(ej4.incluido(lista, lista2));
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
//		System.out.println(ej5.fusion(lista3, lista4));
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
//		System.out.println("Introduzca una cadena y se la introducire caracter por caracter en una lista.");
//		System.out.println(ej6.leeCadena());
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
//		System.out.println("Introduzca dos cadenas y se las concatenare en una lista nueva, caracter a caracter.");
//		System.out.println(ej7.uneCadena(listaChar1, listaChar2));
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
//		System.out.println("Mostrando primera lista y la lista clonada");
//		System.out.println(ej8.clonaLista(lista3));
		System.out.println("");
		System.out.println("-------------------------------------");
		System.out.println("");
		
		
		
	}

}
