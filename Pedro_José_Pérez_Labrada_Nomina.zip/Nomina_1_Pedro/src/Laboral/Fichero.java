/**
 * 
 */
package Laboral;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author estudiante
 *
 */
public class Fichero {
	
	File fichero = new File("empleados.txt");
	Nomina n = new Nomina();
	
	/**
	 * 
	 */
	
	public void anadir(String empleado, String fichero) {
		
		BufferedWriter buw;
		
		try {
			
			buw = new BufferedWriter(new FileWriter(fichero, true));
			buw.write(empleado);
			buw.newLine();
			buw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void leer(String fichero) throws IOException {
		
		BufferedReader buR;
		
		try {
			
			buR = new BufferedReader(new FileReader(fichero));
			
			String linea;
			
			while((linea = buR.readLine()) != null) {
				
				System.out.println(linea);
				
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}catch (IOException io) {
			
			io.printStackTrace();
			
		}
		
	}
	
	public void vaciarFichero(String fichero) {
		
		BufferedWriter buw;
		
		try {
			
			buw = new BufferedWriter(new FileWriter(fichero));
			buw.write("");
			buw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void anadirConDniySueldo(Empleado empleado, String fichero) {
		
		BufferedWriter buw;
		
		try {
			
			buw = new BufferedWriter(new FileWriter(fichero, true));
			buw.write(empleado.dni + "-" + n.sueldo(empleado));
			buw.newLine();
			buw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
