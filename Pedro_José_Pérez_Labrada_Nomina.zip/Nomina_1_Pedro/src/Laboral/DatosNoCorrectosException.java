package Laboral;

public class DatosNoCorrectosException extends Exception {

	public DatosNoCorrectosException(String string) {
		super(string);
	}

	public DatosNoCorrectosException() {
		  super("Datos no introducidos correctamente");
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 8901982656673213978L;

}
