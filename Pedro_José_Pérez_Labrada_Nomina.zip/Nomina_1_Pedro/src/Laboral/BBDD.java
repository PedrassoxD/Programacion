/**
 * 
 */
package Laboral;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author estudiante
 *
 */
public class BBDD {
	
	public void anadir(Empleado emp) throws IOException, DatosNoCorrectosException {
		
		try {
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@172.16.8.133:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			String sexo = Character.toString(emp.sexo);
			
			st = con.prepareStatement("insert into empleado values (?,?,?,?,?)");
			
			st.setString(1, emp.nombre);
			st.setString(2, emp.dni);
			st.setString(3, sexo);
			st.setInt(4, emp.getCategoria());
			st.setInt(5, emp.anyos);
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Empleado insertado.");
			}else {
				System.out.println("Imposible insertar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}

	}
	
	public void leer() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		Statement st;
		
		String url = "jdbc:oracle:thin:@172.16.8.133:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			st = con.createStatement();
			
			ResultSet rs = st.executeQuery("select * from empleado");
			
			while(rs.next()) {
				
				String linea = rs.getString(1) + "-" +  rs.getString(2) + "-" + rs.getString(3) + "-" + rs.getInt(4) + "-" + rs.getInt(5);				
				
				System.out.println(linea);
				
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println();
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getErrorCode());
			System.out.println();
			System.out.println(e.getSQLState());
		}
	}
	
	public void borrarTodosEmpleados() {
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@172.16.8.133:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			st = con.prepareStatement("delete from empleado");
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Empleados eliminados.");
			}else {
				System.out.println("Imposible eliminar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}
		
	}
	
	
	
	
	
}
