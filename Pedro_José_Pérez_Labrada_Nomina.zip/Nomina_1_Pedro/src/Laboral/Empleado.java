/**
 * 
 */
package Laboral;

/**
 * @author pedro
 *
 */
public class Empleado extends Persona {
	//Atributos
	private int categoria;
	public int anyos;
	
	/**
	 * Constructores
	 * @param nombre = nombre del empleado
	 * @param dni = dni del empleado
	 * @param sexo = sexo del empleado
	 * @param categoria = categoria del empleado
	 * @param anyos = anyos del empleado
	 */

	public Empleado(String nombre, String dni, char sexo, int categoria, int anyos) throws DatosNoCorrectosException {
		super(nombre, dni, sexo);
		
		this.setCategoria(categoria);
		
		if(anyos < 0) {
			throw new DatosNoCorrectosException("A�os introducidos incorrectamente.");
		}else {
			this.anyos = anyos;
		}
		
		
	}
	
	public Empleado(String nombre, String dni, char sexo) throws DatosNoCorrectosException {
		super(nombre, dni, sexo);
		this.categoria = 1;
		this.anyos = 0;
	}
	
	//Metodos
	
	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) throws DatosNoCorrectosException {
		
		if(categoria > 0 && categoria < 10) {
			this.categoria = categoria;
		}else {
			throw new DatosNoCorrectosException("Categoria incorrecta.");
		}
	}
	
	public int incrAnyo() {
		return anyos++;
	}
	
	
	public void setSexo(char sexo) throws DatosNoCorrectosException  {
		if(sexo == 'M' || sexo == 'F') {
			this.sexo = sexo;
		}else {
			throw new DatosNoCorrectosException();
		}
	}
	
	
	public String imprime() {
		return nombre + "-" + dni + "-" + sexo + "-" + categoria + "-" + anyos;
	}

}
