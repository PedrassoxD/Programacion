/**
 * 
 */
package Laboral;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author estudiante
 *
 */
public class BBDD {
	
	public void anadirEmpleado(Empleado emp) throws IOException, DatosNoCorrectosException {
		
		try {
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			String sexo = Character.toString(emp.sexo);
			
			st = con.prepareStatement("insert into empleado values (?,?,?,?,?)");
			
			st.setString(1, emp.nombre);
			st.setString(2, emp.dni);
			st.setString(3, sexo);
			st.setInt(4, emp.getCategoria());
			st.setInt(5, emp.anyos);
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Empleado insertado.");
			}else {
				System.out.println("Imposible insertar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}

	}
	
	public void leerTablaEmpleado() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		Statement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			st = con.createStatement();
			
			ResultSet rs = st.executeQuery("select * from empleado");
			
			while(rs.next()) {
				
				String linea = rs.getString(1) + "-" +  rs.getString(2) + "-" + rs.getString(3) + "-" + rs.getInt(4) + "-" + rs.getInt(5);				
				
				System.out.println(linea);
				
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println();
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getErrorCode());
			System.out.println();
			System.out.println(e.getSQLState());
		}
	}
	
	public void borrarTodosEmpleados() {
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			st = con.prepareStatement("delete from empleado");
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Empleados eliminados.");
			}else {
				System.out.println("Imposible eliminar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}
		
	}
	
	public void actualizarCategoria(Empleado emp){
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			st = con.prepareStatement("update empleado set categoria = ? where dni = ?");
			
			st.setInt(1, emp.getCategoria());
			st.setString(2, emp.dni);
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Categoria de " + emp.nombre + " actualizada.");
			}else {
				System.out.println("Imposible actualizar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}
		
	}
	
	public void actualizarAnyos(Empleado emp){
			
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			Connection con;
			PreparedStatement st;
			
			String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
			
			try {
				
				con = DriverManager.getConnection(url, "empleados", "empleados");
				
				int result;
				
				st = con.prepareStatement("update empleado set anyos = ? where dni = ?");
				
				st.setInt(1, emp.anyos);
				st.setString(2, emp.dni);
				
				result = st.executeUpdate();
				
				if(result>0) {
					System.out.println("Anios de " + emp.nombre +" actualizados.");
				}else {
					System.out.println("Imposible actualizar.");
				}
	
			} catch (SQLException e) {
				
				e.printStackTrace();
				
				System.out.println();
				
				System.out.println(e.getMessage());
				System.out.println();
				System.out.println(e.getSQLState());
				System.out.println();
				System.out.println(e.getErrorCode());
			}
			
		}
	
	public void anadirNomina(Empleado emp) throws IOException, DatosNoCorrectosException {
			
		Nomina n = new Nomina();
		
			try {
			
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			Connection con;
			PreparedStatement st;
			
			String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
			
			try {
				
				con = DriverManager.getConnection(url, "empleados", "empleados");
				
				int result;
				
				st = con.prepareStatement("insert into nomina values (?,?)");
				
				st.setString(1, emp.dni);
				st.setInt(2, n.sueldo(emp));
				
				result = st.executeUpdate();
				
				if(result>0) {
					System.out.println("Nomina insertada.");
				}else {
					System.out.println("Imposible insertar.");
				}
	
			} catch (SQLException e) {
				
				e.printStackTrace();
				
				System.out.println();
				
				System.out.println(e.getMessage());
				System.out.println();
				System.out.println(e.getSQLState());
				System.out.println();
				System.out.println(e.getErrorCode());
			}
	
		}
	
	public void borrarDatosTablaNomina() {
			
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			Connection con;
			PreparedStatement st;
			
			String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
			
			try {
				
				con = DriverManager.getConnection(url, "empleados", "empleados");
				
				int result;
				
				st = con.prepareStatement("delete from nomina");
				
				result = st.executeUpdate();
				
				if(result>0) {
					System.out.println("Nominas eliminadas.");
				}else {
					System.out.println("Imposible eliminar.");
				}
	
			} catch (SQLException e) {
				
				e.printStackTrace();
				
				System.out.println();
				
				System.out.println(e.getMessage());
				System.out.println();
				System.out.println(e.getSQLState());
				System.out.println();
				System.out.println(e.getErrorCode());
			}
			
		}
	
	public void leerTablaNomina() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		Statement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			st = con.createStatement();
			
			ResultSet rs = st.executeQuery("select * from Nomina");
			
			while(rs.next()) {
				
				String linea = rs.getString(1) + "-" +  rs.getInt(2);				
				
				System.out.println(linea);
				
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println();
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getErrorCode());
			System.out.println();
			System.out.println(e.getSQLState());
		}
	}
	
	public void actualizarSueldoNomina(Empleado emp) {
		
		Nomina n = new Nomina();
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			st = con.prepareStatement("update nomina set sueldo = ? where dni = ?");
			
			st.setInt(1, n.sueldo(emp));
			st.setString(2, emp.dni);
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Sueldo de " + emp.nombre +" actualizado.");
			}else {
				System.out.println("Imposible actualizar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}
		
	}
	
	public void altaEmpleado(Empleado emp) {
		
		Nomina n = new Nomina();
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			String sexo = Character.toString(emp.sexo);
			
			st = con.prepareStatement("insert into empleado values (?,?,?,?,?)");
			
			st.setString(1, emp.nombre);
			st.setString(2, emp.dni);
			st.setString(3, sexo);
			st.setInt(4, emp.getCategoria());
			st.setInt(5, emp.anyos);
			
			st.executeUpdate();
			
			st = con.prepareStatement("insert into nomina values (?,?)");
			
			st.setString(1, emp.dni);
			st.setInt(2, n.sueldo(emp));
			
			
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Empleado insertado.");
			}else {
				System.out.println("Imposible insertar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}
		
	}
	
	public void buckup(String fichero1, String fichero2) {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		Statement st;
		BufferedWriter buw;
		BufferedWriter buw2;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			buw = new BufferedWriter(new FileWriter(fichero1, true));
			
			st = con.createStatement();
			
			ResultSet rs = st.executeQuery("select * from empleado");
			
			while(rs.next()) {
				
				String linea = rs.getString(1) + "-" +  rs.getString(2) + "-" + rs.getString(3) + "-" + rs.getInt(4) + "-" + rs.getInt(5);
				
				buw.write(linea);
				buw.newLine();
			}
			buw.close();
			
			buw2 = new BufferedWriter(new FileWriter(fichero2, true));
			
			st.clearBatch();
			st = con.createStatement();
			
			rs = st.executeQuery("select * from Nomina");
			
			while(rs.next()) {
				
				String linea = rs.getString(1) + "-" +  rs.getInt(2);				
				
				buw2.write(linea);
				buw2.newLine();
			}
			buw2.close();
			
			
			
			
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println();
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getErrorCode());
			System.out.println();
			System.out.println(e.getSQLState());
		}catch (IOException io) {
			io.printStackTrace();
		}
		
	}
	
	public void leerTablaNominaPorDni(String dni) {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		ResultSet rs;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			st = con.prepareStatement("select * from nomina where dni = ?");
			st.setString(1, dni);
			rs = st.executeQuery();
			
			while(rs.next()) {
				
				String linea = rs.getString(1) + "-" +  rs.getInt(2);				
				
				System.out.println(linea);
				
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println();
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getErrorCode());
			System.out.println();
			System.out.println(e.getSQLState());
		}
	}
	
	public void actualizarNombre(String nombre, String dni) {
			
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			Connection con;
			PreparedStatement st;
			
			String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
			
			try {
				
				con = DriverManager.getConnection(url, "empleados", "empleados");
				
				int result;
				
				st = con.prepareStatement("update empleado set nombre = ? where dni = ?");
				
				st.setString(1, nombre);
				st.setString(2, dni);
				
				result = st.executeUpdate();
				
				if(result>0) {
					System.out.println("Nombre del empleado actualizado.");
				}else {
					System.out.println("Imposible actualizar.");
				}
	
			} catch (SQLException e) {
				
				e.printStackTrace();
				
				System.out.println();
				
				System.out.println(e.getMessage());
				System.out.println();
				System.out.println(e.getSQLState());
				System.out.println();
				System.out.println(e.getErrorCode());
			}
			
		}
	
	public void actualizarSexo(String sexo, String dni) {
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			int result;
			
			st = con.prepareStatement("update empleado set sexo = ? where dni = ?");
			
			st.setString(1, sexo);
			st.setString(2, dni);
			
			result = st.executeUpdate();
			
			if(result>0) {
				System.out.println("Sexo del empleaedo actualizado.");
			}else {
				System.out.println("Imposible actualizar.");
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}
		
	}
	
	public void actualizarCategoriaPorDni(int categoria, String dni){
			
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			Connection con;
			PreparedStatement st;
			
			String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
			
			try {
				
				con = DriverManager.getConnection(url, "empleados", "empleados");
				
				int result;
				
				st = con.prepareStatement("update empleado set categoria = ? where dni = ?");
				
				st.setInt(1, categoria);
				st.setString(2, dni);
				
				result = st.executeUpdate();
				
				if(result>0) {
					System.out.println("Categoria actualizada.");
				}else {
					System.out.println("Imposible actualizar.");
				}
	
			} catch (SQLException e) {
				
				e.printStackTrace();
				
				System.out.println();
				
				System.out.println(e.getMessage());
				System.out.println();
				System.out.println(e.getSQLState());
				System.out.println();
				System.out.println(e.getErrorCode());
			}
			
		}
	
	public void actualizarAnyosPorDni(int anyos, String dni){
			
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			Connection con;
			PreparedStatement st;
			
			String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
			
			try {
				
				con = DriverManager.getConnection(url, "empleados", "empleados");
				
				int result;
				
				st = con.prepareStatement("update empleado set anyos = ? where dni = ?");
				
				st.setInt(1, anyos);
				st.setString(2, dni);
				
				result = st.executeUpdate();
				
				if(result>0) {
					System.out.println("Anyos actualizados.");
				}else {
					System.out.println("Imposible actualizar.");
				}
	
			} catch (SQLException e) {
				
				e.printStackTrace();
				
				System.out.println();
				
				System.out.println(e.getMessage());
				System.out.println();
				System.out.println(e.getSQLState());
				System.out.println();
				System.out.println(e.getErrorCode());
			}
			
		}
	
	public void actualizarSueldoPorDni(String dni) {
			
			Nomina n = new Nomina();
			
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			Connection con;
			PreparedStatement st;
			ResultSet rs;
			Empleado emp;
			
			String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
			
			try {
				
				con = DriverManager.getConnection(url, "empleados", "empleados");
				
				st = con.prepareStatement("select * from empleado where dni = ?");
				st.setString(1, dni);
				rs = st.executeQuery();
				
				while(rs.next()) {
					
					emp = new Empleado(rs.getString(1), rs.getString(2), rs.getString(3).charAt(0), rs.getInt(4), rs.getInt(5));
					
					int result;
					
					st = con.prepareStatement("update nomina set sueldo = ? where dni = ?");
					
					st.setInt(1, n.sueldo(emp));
					st.setString(2, emp.dni);
					
					result = st.executeUpdate();
					
					if(result>0) {
						System.out.println("Sueldo actualizado.");
					}else {
						System.out.println("Imposible actualizar.");
					}
					
				}

			} catch (SQLException e) {
				
				e.printStackTrace();
				
				System.out.println();
				
				System.out.println(e.getMessage());
				System.out.println();
				System.out.println(e.getSQLState());
				System.out.println();
				System.out.println(e.getErrorCode());
			}catch (DatosNoCorrectosException Dan) {
				Dan.getMessage();
			}
			
		}
	
	public void actualizarSueldoATodos() {
		
		Nomina n = new Nomina();
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Connection con;
		PreparedStatement st;
		ResultSet rs;
		Empleado emp;
		
		String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
		
		try {
			
			con = DriverManager.getConnection(url, "empleados", "empleados");
			
			st = con.prepareStatement("select * from empleado");
			rs = st.executeQuery();
			
			while(rs.next()) {
				
				emp = new Empleado(rs.getString(1), rs.getString(2), rs.getString(3).charAt(0), rs.getInt(4), rs.getInt(5));
				
				int result;
				
				st = con.prepareStatement("update nomina set sueldo = ? where dni = ?");
				
				st.setInt(1, n.sueldo(emp));
				st.setString(2, emp.dni);
				
				result = st.executeUpdate();
				
				if(result>0) {
					System.out.println("Sueldos de todos los empleados actualizado.");
				}else {
					System.out.println("Imposible actualizar.");
				}
				
			}

		} catch (SQLException e) {
			
			e.printStackTrace();
			
			System.out.println();
			
			System.out.println(e.getMessage());
			System.out.println();
			System.out.println(e.getSQLState());
			System.out.println();
			System.out.println(e.getErrorCode());
		}catch (DatosNoCorrectosException Dan) {
			Dan.getMessage();
		}
		
	}
		
	
	
}
