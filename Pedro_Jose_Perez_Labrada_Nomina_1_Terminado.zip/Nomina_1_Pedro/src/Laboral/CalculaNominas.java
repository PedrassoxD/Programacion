/**
 * 
 */
package Laboral;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * @author pedro
 *
 */
public class CalculaNominas {

	/**
	 * @param args
	 * @throws DatosNoCorrectosException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException, DatosNoCorrectosException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Scanner sx = new Scanner(System.in);
		
		BBDD bd = new BBDD();
		Fichero fiche = new Fichero();
		Empleado emp1 = new Empleado("James Cosling","32000032G",'M',4,7);
		Empleado emp2 = new Empleado("Ada Lovelace","32000031R",'F',1,0);
		
		
		/**
		 * PARTE 1 DEL EXAMEN DE NOMINA
		 */
		
//		try {
//			
//			//Mostramos a los empleados con su sueldo.
//			
//			escribe(emp1);
//			System.out.println();
//			System.out.println();
//			escribe(emp2);
//			
//			System.out.println("----------------------------------");
//			
//			//Incrementamos en 1 el anyo del emp2 y cambiamos la caregoria del emp1 de 4 a 9.
//			
//			emp2.incrAnyo();
//			emp1.setCategoria(9);
//			
//			escribe(emp1);
//			System.out.println();
//			System.out.println();
//			escribe(emp2);
//			
//		} catch (DatosNoCorrectosException e) {
//			// TODO Auto-generated catch block
//			System.out.println("Datos no correctos.");
//			e.printStackTrace();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
/**
 * ----------------------------------------------------------------------------------------------------------------------------------		
 */
		
		/**
		 * PARTE 2 DEL EXAMEN
		 */
		
		/**
		 * FICHEROS
		 */
		
		System.out.println("FICHEROS");
		
		/**
		 *  Definir el fichero de texto de entrada �empleados.txt� creando en el mismo los empleados de los 
		 *  apartados 4.1 y 4.2 con el formato m�s adecuado para que pueda 
		 *  ser le�do por el programa.
		 */
		
		String fichero = "empleados.txt";
		
		fiche.anadir(emp1,fichero);
		fiche.anadir(emp2, fichero);
		System.out.println();
		System.out.println("empleados.txt");
		fiche.leer(fichero);
		
		//Si quiere vaciar el fichero descomente la linea de abajo
//		fiche.vaciarFichero(fichero);
		
		System.out.println();
		System.out.println();
		
		
		/**
		 * Escritura del dni junto con el sueldo en fichero salarios.dat
		 */

		String fichero2 = "salarios.dat";
		
		fiche.anadirFicheroBinarioDniSueldo(fichero2, emp1);
		fiche.anadirFicheroBinarioDniSueldo(fichero2, emp2);
		
		System.out.println("salarios.dat");
		fiche.leerFicheroBinarioDniSueldo(fichero2);
		
//		//Si quiere vaciar el fichero descomente la linea de abajo	
//		fiche.eliminarDatosFicheroBinario(fichero2);
		
		
		System.out.println();
		System.out.println();
		
		
		/**
		 * 1.2. Actualizar dicho fichero �empleados.txt� conforme a los cambios especificados en el apartado 4.5. 
		 */
		
		emp1.setCategoria(9);
		emp2.incrAnyo();
		
		//Primero vaciamos el fichero y luego introducimos el empleado actulalizado anteriormente en las lineas 140 y 141
		
		fiche.vaciarFichero(fichero);
		
		fiche.actualizaEmpleado(fichero, emp1);
		fiche.actualizaEmpleado(fichero, emp2);
		
		//Por ultimo, mostramos los datos.
		System.out.println("empleados.txt");
		fiche.leer(fichero);
		
		
		System.out.println();
		System.out.println();
		
		/**
		 * 1.3. Definir el fichero binario de salida �sueldos.dat� 
		 * con el formato m�s adecuado para almacenar el dni y el sueldo resultante para cada empleado. 
		 */

		String fichero3 = "sueldos.dat";
		
		fiche.anadirFicheroBinarioDniSueldo(fichero3, emp1);
		fiche.anadirFicheroBinarioDniSueldo(fichero3, emp2);
		
		System.out.println("sueldos.dat");
		fiche.leerFicheroBinarioDniSueldo(fichero3);
		
//		//Si quiere vaciar el fichero descomente la linea de abajo
//		fiche.eliminarDatosFicheroBinario(fichero3);
		
		
/**
 * ----------------------------------------------------------------------------------------------------------------------------------		
 */
		System.out.println();
		System.out.println();
		
		
		/**
		 * BASE DE DATOS.
		 */
		
		System.out.println("BASE DE DATOS.");
		
		Empleado emp3 = new Empleado("James Cosling","32000032G",'M',4,7);
		Empleado emp4 = new Empleado("Ada Lovelace","32000031R",'F',1,0);
		
		/**
		 * 2.1. Definir e implementar el modelo de tablas y relaciones necesarios para dar soporte 
		 * a la aplicaci�n de control de n�minas. Definir en la tabla correspondiente de dicha 
		 * base de datos los mismos los empleados de los apartados 4.1 y 4.2 de la parte 1 para que pueda ser le�do por el programa
		 */
	
		bd.anadirEmpleado(emp3);
		bd.anadirEmpleado(emp4);
		System.out.println();
		System.out.println("Tabla Empleado.");
		bd.leerTablaEmpleado();
		
		//Borrar todos los empleados de la base de datos.		
//		bd.borrarTodosEmpleados();
		
		
		System.out.println();
		System.out.println();
		
		
		/**
		 * Tabla Nominas
		 */
		
		bd.anadirNomina(emp3);
		bd.anadirNomina(emp4);
		System.out.println();
		System.out.println("Tabla Nomina.");
		bd.leerTablaNomina();
		
		//Borrar todas las nominas de la base de datos.	
//		bd.borrarDatosTablaNomina();
		
		
		
		
		/**
		 * 2.2. Actualizar dicha base de datos conforme a los cambios especificados en el apartado 4.5 de la parte 1. 
		 * 2.3. Actualizar la base de datos almacenando el sueldo resultante para cada empleado. 
		 */
		
		
		emp3.setCategoria(9);
		emp4.incrAnyo();
		
		bd.actualizarCategoria(emp3);
		bd.actualizarAnyos(emp4);
		System.out.println();
		System.out.println("Tabla Empleado.");
		bd.leerTablaEmpleado();
		System.out.println();
		bd.actualizarSueldoNomina(emp3);
		bd.actualizarSueldoNomina(emp4);
		System.out.println();
		System.out.println("Tabla Nomina.");
		bd.leerTablaNomina();
		
		
		System.out.println();
		System.out.println();
		
		
		/**
		 * 3.1 Sobrecargar el m�todo �altaEmpleado� para que permita el alta de empleados de forma 
		 * individual o por lotes a partir de un fichero �empleadosNuevos.txt� con los datos 
		 * de los empleados a dar de alta en el sistema.
		 */
		
		//Anadir empleados en fichero empleadosNuevos.txt
		String fichEmpleadosNuevos = "empleadosNuevos.txt";
		
		Empleado empleado = new Empleado("Lolito Fernandez","25436521H",'M',7,4);
		Empleado empleado2 = new Empleado("Pajaro Loco","58463278P",'M',8,3);
		Empleado empleado3 = new Empleado("Eustaquio Abichuela","54862578E",'M',2,4);
		Empleado empleado4 = new Empleado("Murien Dome","63542458M",'F',6,2);
		
		fiche.anadir(empleado, fichEmpleadosNuevos);
		fiche.anadir(empleado2, fichEmpleadosNuevos);
		fiche.anadir(empleado3, fichEmpleadosNuevos);
		fiche.anadir(empleado4, fichEmpleadosNuevos);
		System.out.println();
		System.out.println("empleadosNuevos.txt");
		fiche.leer(fichEmpleadosNuevos);
		
//		//Si quiere vaciar el fichero descomente la linea de abajo
//		fiche.vaciarFichero(fichEmpleadosNuevos);
		
		altaEmpleados(fichEmpleadosNuevos);
		
		
		System.out.println();
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		
			
		/**
		 * MENU DE OPCIONES
		 */
		
		System.out.println("MENU DE OPCIONES");
		
		int opcion;
		
		do {
			System.out.println();
			System.out.println("1. Mostrar toda la informacion de todos los empleados.\n" +
								"2. Mostrar el salario de un empleado por su dni.\n" +
								"3. Modificar datos de empleados.\n" +
								"4. Recalcular y actualizar el sueldo de un empleado.\n" +
								"5. Recalcular y actualizar los sueldos de todos los empleados.\n" +
								"6. Realizar copia de seguridad.\n" +
					 			"0. Salir del programa.");
			
			opcion = sx.nextInt();
			
			if(opcion == 1) {
				
				System.out.println("Empleados");
				bd.leerTablaEmpleado();
				System.out.println();
				System.out.println();
				System.out.println("Salarios");
				bd.leerTablaNomina();
				
			}else if(opcion == 2) {
				
				String dni;
				
				System.out.println("Introduce el dni del empleado que desea ver su salario");
				dni = sc.nextLine();
				
				System.out.println("Sueldo del empleado.");
				bd.leerTablaNominaPorDni(dni);
				
			}else if(opcion == 3) {
				
				int opcion2;
				String nombre;
				String dni;
				String sexo;
				int categoria;
				int anyos;
				
				System.out.println("Ha entrado en la opcion de modificar datos de empleado." + 
									"�Que desea modificar?");
				
				do {
					System.out.println("1.- Modificar nombre.\n"
							 + "2.- Modificar sexo.\n"
							 + "3.- Modificar categoria.\n"
							 + "4.- Modificar anyos.\n"
							 + "0.- Salir.");
					
					opcion2 = sx.nextInt();
					
					if(opcion2 == 1) {
						
						System.out.println("Introduzca el dni del empleado a modificar.");
						
						dni = sc.nextLine();
						
						System.out.println("Ahora escriba el nuevo nombre");
						
						nombre = sc.nextLine();
						
						bd.actualizarNombre(nombre, dni);
					}else if(opcion2 == 2) {
						
						System.out.println("Introduzca el dni del empleado a modificar.");
						
						dni = sc.nextLine();
						
						System.out.println("Ahora escriba el nuevo sexo. Recuerde (M o F)");
						
						sexo = sc.nextLine();
						
						bd.actualizarSexo(sexo, dni);
					
					}else if(opcion2 == 3) {
						
						System.out.println("Introduzca el dni del empleado a modificar.");
						
						dni = sc.nextLine();
						
						System.out.println("Ahora escriba la nueva categoria del empleado.\n" + 
											"Recuerde que al cambiar la categoria tambien debe recalcular el sueldo \n" + 
											"en el apartado 4 o 5 del menu principal");
						
						categoria = sx.nextInt();
						
						bd.actualizarCategoriaPorDni(categoria, dni);
						
					}else if(opcion2 == 4) {
						
						System.out.println("Introduzca el dni del empleado a modificar.");
						
						dni = sc.nextLine();
						
						System.out.println("Ahora escriba los anyos del empleado.\n" + 
								"Recuerde que al cambiar los anyos tambien debe recalcular el sueldo \n" + 
								"en el apartado 4 o 5 del menu principal.");
						
						anyos = sx.nextInt();
						
						bd.actualizarAnyosPorDni(anyos, dni);
						
					}
					
						if(opcion2 == 0) {
						
						System.out.println("Saliendo del submenu...");
						
					}
					
				}while(opcion2 != 0);
				
			}else if(opcion == 4) {
				
				String dni;
				
				System.out.println("Ha entrado en la opcion de recalcular el sueldo de un empleado.");
				
				System.out.println("Introduzca el dni del empleado.");
				
				dni = sc.nextLine();
				
				bd.actualizarSueldoPorDni(dni);
				
			}else if(opcion == 5) {
				
				System.out.println("Ha entrado en la opcion de recalcular el sueldo para todos los empleados.");
				
				bd.actualizarSueldoATodos();
				
			}else if(opcion == 6) {
				
				System.out.println("Ha entrado en la opcion de hacer una copia de seguridad en los ficheros empleados.txt y salarios.txt");
				
				String ficheroEmpleado = "empleados.txt";
				String ficheroSalario = "salarios.txt";
				
				//Vaciamos el contenido del fichero para evitar duplicados
				
				fiche.vaciarFichero(ficheroEmpleado);
				fiche.vaciarFichero(ficheroSalario);
				
				bd.buckup(ficheroEmpleado, ficheroSalario);
				
				System.out.println("empleados.txt");
				fiche.leer(ficheroEmpleado);
				System.out.println();
				System.out.println();
				System.out.println("salarios.txt");
				fiche.leer(ficheroSalario);
				
			}
			
				if(opcion == 0) {
				
				System.out.println("Saliendo...");
				
			}
		
		}while(opcion != 0);
		
		sc.close();
		sx.close();
		
	}
	
	//Metodo de la parte 1
	
//	private static void escribe(Empleado e) {
//		Nomina n = new Nomina();
//		
//		System.out.println(e.imprime());
//		
//		System.out.println("Sueldo: " + n.sueldo(e));
//		
//	}
	
	public static void altaEmpleados(String fichEmpleadoNuevo) throws DatosNoCorrectosException{
		Scanner sc = new Scanner(System.in);
		Scanner sx = new Scanner(System.in);
		BBDD bd = new BBDD();
		Nomina n = new Nomina();
		String dni;
		String nombre;
		String sexo;
		int categoria;
		int anyos;
		String salir;
		int opcion;
		
		do {
			System.out.println();
			System.out.println("1.- Para dar de alta a un empleado individualmente.\n" + 
								"2.- Para dar de alta a empleados por lote desde el fichero empleadosNuevos.txt\n" + 
								"0.- Para salir.");
			
			opcion = sx.nextInt();
			
			if(opcion == 1) {
				System.out.println("Ha entrado en la opcion de introducir empleados individualmente");
				
				do {
					System.out.println("Introduzca los datos del empleado.");
					System.out.println("Nombre");
					nombre = sc.nextLine();
					System.out.println("DNI");
					dni = sc.nextLine();
					System.out.println("Sexo (M o F)");
					sexo = sc.nextLine();
					System.out.println("Categoria");
					categoria = sx.nextInt();
					System.out.println("Anyos");
					anyos = sx.nextInt();
					
					bd.altaEmpleado(new Empleado(nombre,dni,sexo.charAt(0),categoria,anyos));
					
					System.out.println();
					
					System.out.println("�Desea seguir introduciendo empleados? \n" + 
										"Si para seguir, No para salir.");
					
					salir = sc.nextLine();
					
					if(salir.equalsIgnoreCase("no")) {
						System.out.println("Saliendo...");
					}
					
				}while(!salir.equalsIgnoreCase("no"));
				
			}else if(opcion == 2) {
				
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				System.out.println("Ha entrado en la opcion de introducir empleados por lotes desde \n" + 
									"el fichero empleadosNuevos.txt");
				
				String url = "jdbc:oracle:thin:@192.168.0.108:1521:xe";
				
				Connection con;
				PreparedStatement st;				
				BufferedReader buR;
				
				try {
					
					con = DriverManager.getConnection(url, "empleados", "empleados");
					
					buR = new BufferedReader(new FileReader(fichEmpleadoNuevo));
					
					String linea;
					String arrayEmpleado[];
					int result;
					
					while((linea = buR.readLine()) != null) {
						
						arrayEmpleado = linea.split("-");
						
						st = con.prepareStatement("insert into empleado values (?,?,?,?,?)");
						
						st.setString(1, arrayEmpleado[0]);
						st.setString(2, arrayEmpleado[1]);
						st.setString(3, arrayEmpleado[2]);
						st.setInt(4, Integer.parseInt(arrayEmpleado[3]));
						st.setInt(5, Integer.parseInt(arrayEmpleado[4]));
						
						nombre = arrayEmpleado[0];
						dni = arrayEmpleado[1];
						sexo = arrayEmpleado[2];
						categoria = Integer.parseInt(arrayEmpleado[3]);
						anyos = Integer.parseInt(arrayEmpleado[4]);
						
						st.executeUpdate();
						
						st = con.prepareStatement("insert into nomina values (?,?)");
						
						Empleado emp = new Empleado(nombre, dni, sexo.charAt(0), categoria, anyos);
						
						st.setString(1, emp.dni);
						st.setInt(2, n.sueldo(emp));
						
						result = st.executeUpdate();
						
						if(result>0) {
							System.out.println("Empleado insertado.");
						}else {
							System.out.println("Imposible insertar.");
						}
						
					}
					
					
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (IOException io) {
					io.printStackTrace();
				}catch (SQLException sq) {
					
					sq.printStackTrace();
					sq.getMessage();
					sq.getErrorCode();
					sq.getSQLState();
					
				}catch (DatosNoCorrectosException dan) {
					dan.getMessage();
				}

			}else if(opcion == 0) {
				System.out.println("Saliendo...");
			}

		}while(opcion != 0);
		
		sc.close();
		sx.close();
	}

}
