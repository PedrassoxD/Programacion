/**
 * 
 */
package Laboral;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author estudiante
 *
 */
public class Fichero {
	
	File fichero = new File("empleados.txt");
	Nomina n = new Nomina();
	
	/**
	 * 
	 */
	
	public void anadir(Empleado emp, String fichero) {
		
		BufferedWriter buw;
		
		try {
			
			buw = new BufferedWriter(new FileWriter(fichero, true));
			String empleado = emp.imprime();
			buw.write(empleado);
			buw.newLine();
			buw.close();
			
			if(fichero != null) {
				System.out.println("Empleado insertado en fichero.");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void leer(String fichero) throws IOException {
		
		BufferedReader buR;
		
		try {
			
			buR = new BufferedReader(new FileReader(fichero));
			
			String linea;
			
			while((linea = buR.readLine()) != null) {
				
				System.out.println(linea);
				
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}catch (IOException io) {
			
			io.printStackTrace();
			
		}
		
	}
	
	public void vaciarFichero(String fichero) {
		
		BufferedWriter buw;
		
		try {
			
			buw = new BufferedWriter(new FileWriter(fichero));
			buw.write("");
			buw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void anadirConDniySueldo(Empleado empleado, String fichero) {
		
		BufferedWriter buw;
		
		try {
			
			buw = new BufferedWriter(new FileWriter(fichero, true));
			buw.write(empleado.dni + "-" + n.sueldo(empleado));
			buw.newLine();
			buw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void anadirFicheroBinarioDniSueldo(String fichero,Empleado emp) {
		
		Nomina n = new Nomina();
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		String sueldo;
		
		try {
			
			fos = new FileOutputStream(fichero,true);
			dos = new DataOutputStream(fos);
			
			sueldo = Integer.toString(n.sueldo(emp));
			
			dos.writeUTF(emp.dni + "-" + sueldo + "\n");
			
			fos.close();
			dos.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException io) {
			io.printStackTrace();
		}
		
	}
	
	public void leerFicheroBinarioDniSueldo(String fichero) {
		
		FileInputStream fis = null;
		DataInputStream dis = null;
		try {
			
			fis = new FileInputStream(fichero);
			dis = new DataInputStream(fis);
			
			while(true) {
				System.out.println(dis.readUTF());
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (EOFException eo){
			System.out.println("Fin del fichero.");
		}catch (IOException io) {
			io.printStackTrace();
		}
		
	}
	
	public void eliminarDatosFicheroBinario(String fichero) {
		
		FileOutputStream fos= null;
		DataOutputStream dos = null;
		
		try {
			
			fos = new FileOutputStream(fichero);
			dos = new DataOutputStream(fos);
			
			dos.writeUTF("");
			
			fos.close();
			dos.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException io) {
			io.printStackTrace();
		}
		
	}
	
	public void actualizaEmpleado(String fichero, Empleado emp) throws DatosNoCorrectosException {
		
		BufferedWriter buw;
		
			try {
				
				buw = new BufferedWriter(new FileWriter(fichero,true));
				String empleado = emp.imprime();
				buw.write(empleado);
				buw.newLine();
				buw.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
}
